fx_version 'adamant'

game 'gta5' 

author 'sjpfeiffer'
description 'A ped spawner for fivem'
version '1.2.0'

lua54 'yes'

client_scripts {
	'config.lua',
	'client/main.lua'
}