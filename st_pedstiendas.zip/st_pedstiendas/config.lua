Config = {}
Config.Invincible = true --¿Qué, ¿quieres que los PED sean invencibles?
Config.Frozen = true --¿Quieres que los PED no puedan moverse?Probablemente sea un sí, así que deja verdad allí.
Config.Stoic = true --¿Quieres que los PED reaccionen a lo que está sucediendo en su entorno?
Config.Fade = true-- ¿Quieres que los PED se vean dentro/fuera de la existencia? 
Config.Distance = 60.0 --La distancia a la que quieres que los peds se vean


Config.MinusOne = true

Config.PedList = {
	{--------------------------- concecionario normal
	model = "s_m_m_movprem_01", --El nombre del modelo de ped. https://docs.fivem.net/docs/game-references/ped-models/
	coords = vector3(-56.8658, -1096.6208, 26.3710), --ubicacion en la que vas a dejar el ped
	heading = 247.2845,  --ubicacion en la que vas a dejar el ped
	gender = "male", --Usa hombre o mujer
	-- animDict = "", --El diccionario de animación. Opcional. Comentar o eliminar si no lo usa.
	-- animName = "", --El nombre de la animación.Opcional. Comentar o eliminar si no lo usa.
	isRendered = false,
	ped = nil,
},


}

